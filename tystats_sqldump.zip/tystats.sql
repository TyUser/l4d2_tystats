
SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

CREATE TABLE IF NOT EXISTS `tystatsplayers` (
  `steamid` varchar(32) NOT NULL DEFAULT '',
  `points` int(11) NOT NULL DEFAULT '0',
  `name` tinyblob NOT NULL,
  `lastontime` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`steamid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
