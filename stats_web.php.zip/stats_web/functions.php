<?php
/**
 * vim: set ts=4 :
 * =============================================================================
 * L4D2 Coop Stats
 * Copyright 2014 www.russerver.com
 * =============================================================================
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License, version 3.0, as published by the
 * Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * As a special exception, AlliedModders LLC gives you permission to link the
 * code of this program (as well as its derivative works) to "Half-Life 2," the
 * "Source Engine," the "SourcePawn JIT," and any Game MODs that run on software
 * by the Valve Corporation.  You must obey the GNU General Public License in
 * all respects for all other code used.  Additionally, AlliedModders LLC grants
 * this exception to all derivative works.  AlliedModders LLC defines further
 * exceptions, found in LICENSE.txt (as of this writing, version JULY-31-2007),
 * or <http://www.sourcemod.net/license.php>.
 *
 * Version: $Id$
 *
 *	include 'functions.php';
 *	echo TyGetTop('cacheTop.txt', 'localhost', 'db user', 'db password', 'db name');
 *
 *	echo TyGetOnline('cacheOnline.txt', 'localhost', 'db user', 'db password', 'db name');
 *
 */

error_reporting (E_ALL);
ini_set('display_errors',1);

function TyFreshFile($sCache)
{
	if(file_exists($sCache))
	{
		if((time()-10)<filemtime($sCache)){return 1;}
	}
	return 0;
}

function TyGetTop($sCache, $sHostSQL, $sUsernameSQL, $sPasswordSQL, $sDBnameSQL)
{
	if(TyFreshFile($sCache)){return file_get_contents($sCache);}

	$FileCache = fopen($sCache, 'w');
	if($FileCache != false)
	{
		$link = mysqli_connect($sHostSQL, $sUsernameSQL, $sPasswordSQL, $sDBnameSQL);
		if(mysqli_connect_errno()){return 'error connect SQL';}

		mysqli_query($link, "SET NAME 'utf8'");
		$sBuffer="\t<h2>Top 10</h2>\n\t<p>\n";
		fwrite($FileCache, $sBuffer);

		$sSteam='		';
		$iPoints=0;
		$sName='		';
		$sDate='		';
		$iTime=time();
		$i=0;

		$sQuery = "SELECT * FROM `tystatsplayers` ORDER BY points DESC LIMIT 10";
		if($result = mysqli_query($link, $sQuery))
		{
			while ($row = mysqli_fetch_assoc($result))
			{
				$sSteam = $row['steamid'];
				$iPoints = number_format($row['points']);
				$sName = htmlentities($row['name'], ENT_QUOTES, "UTF-8");
				$i +=1;

				$sBuffer="\t\t<br>".$i.' &nbsp;&nbsp; '.$sName.' &nbsp;&nbsp; '.$sSteam.' &nbsp;&nbsp; '.$iPoints." Points\n";

				fwrite($FileCache, $sBuffer);
			}
			mysqli_free_result($result);
		}
		$sBuffer="\t</p>\n\t<br>\n";
		fwrite($FileCache, $sBuffer);
		fclose($FileCache);
		mysqli_close($link);

		return file_get_contents($sCache);
	}
	return 'error Cache';
}

function TyGetOnline($sCache, $sHostSQL, $sUsernameSQL, $sPasswordSQL, $sDBnameSQL)
{
	if(TyFreshFile($sCache)){return file_get_contents($sCache);}

	$FileCache = fopen($sCache, 'w');
	if($FileCache != false)
	{
		$link = mysqli_connect($sHostSQL, $sUsernameSQL, $sPasswordSQL, $sDBnameSQL);
		if(mysqli_connect_errno()){return 'error connect SQL';}

		mysqli_query($link, "SET NAME 'utf8'");
		$sBuffer="\t<h2>Players online</h2>\n\t<p>\n";
		fwrite($FileCache, $sBuffer);

		$sSteam='		';
		$iPoints=0;
		$sName='		';
		$iTime=time();
		$iTime1=time()-1100;
		$i=0;

		$sQuery = "SELECT * FROM `tystatsplayers` WHERE lastontime >'".$iTime1."' AND lastontime <'".$iTime."' ORDER BY points DESC LIMIT 30";
		if($result = mysqli_query($link, $sQuery))
		{
			while ($row = mysqli_fetch_assoc($result))
			{
				$sSteam = $row['steamid'];
				$iPoints = number_format($row['points']);
				$sName = htmlentities($row['name'], ENT_QUOTES, "UTF-8");
				$i +=1;

				$sBuffer="\t\t<br>".$i.' &nbsp;&nbsp; '.$sName.' &nbsp;&nbsp; '.$sSteam.' &nbsp;&nbsp; '.$iPoints." Points\n";

				fwrite($FileCache, $sBuffer);
			}
			mysqli_free_result($result);
		}
		$sBuffer="\t</p>\n\t<br>\n";
		fwrite($FileCache, $sBuffer);
		fclose($FileCache);
		mysqli_close($link);

		return file_get_contents($sCache);
	}
	return 'error Cache';
}

