<?php
include 'functions.php';

echo '
<!doctype html>
<html>
<head>
	<meta charset="UTF-8" />
	<title>				</title>
	<meta name="keywords" content="									" />
	<meta name="description" content="								" />
</head>
<body>
';

echo TyGetOnline('cacheOnline.txt', 'localhost', 'db user', 'db password', 'db name');

echo '</body></html>';

